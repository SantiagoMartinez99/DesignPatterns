
class FlyweightIntr(object):
    
    def __init__(self):
        pass
   
    def getCompany(self):
        raise Exception("NotImplementedException")

    def getAddress(self):
        raise Exception("NotImplementedException")

    def getCity(self):
        raise Exception("NotImplementedException")

    def getState(self):
        raise Exception("NotImplementedException")

    def getZip(self):
        raise Exception("NotImplementedException")
